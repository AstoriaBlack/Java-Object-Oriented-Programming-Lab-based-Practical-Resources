/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.numberprintproject;

/**
 *
 * @author b.villarini
 */
public class NumberPrinterThread implements Runnable{
    
    NumberPrinter printer;
    
    public NumberPrinterThread(NumberPrinter printer ){
        this.printer = printer;
    }
        

    @Override
    public void run() {
        
        while (printer.currentIndex <= printer.numbersList.size()) {
                    printer.printNextNumber();
                    try {
                        Thread.sleep(100); // Simulate some delay
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }
    
}
