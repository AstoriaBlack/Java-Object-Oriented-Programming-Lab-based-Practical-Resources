/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.numberprintproject;

import java.util.*;

/**
 *
 * @author b.villarini
 */
public class NumberPrinter {
    
    public final List<Integer> numbersList = new ArrayList<>();
    public int currentIndex = 0;

    public NumberPrinter(int range) {
        for (int i = 1; i <= range; i++) {
            numbersList.add(i);
        }
    }

    public void printNextNumber() {
        
        // follow the comments to implement your code:
        
        // 1 - Check if current index is less then the total number of element in the list
        // 2 - if 1) is true then print on the screen the current thread name and the current element in the list 
        // 3 - else print on  the screen the current thread name and that there are no more elements to print
        // 4 - also consider that you have to upadte currendIndex to print the next number
        
       
    }
    
}
